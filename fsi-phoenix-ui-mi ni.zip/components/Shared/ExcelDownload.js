import  React, { useState, useEffect } from 'react';
import ReactExport from "react-export-excel";

import { Link } from "react-router-dom";
import FeatherIcon from "feather-icons-react";

const ExcelFile = ReactExport.ExcelFile;
const ExcelSheet = ReactExport.ExcelFile.ExcelSheet;
const ExcelColumn = ReactExport.ExcelFile.ExcelColumn;

// const dataSet1 = [
//     {
//         name: "Johson",
//         amount: 30000,
//         sex: 'M',
//         is_married: true
//     },
//     {
//         name: "Monika",
//         amount: 355000,
//         sex: 'F',
//         is_married: false
//     },
//     {
//         name: "John",
//         amount: 250000,
//         sex: 'M',
//         is_married: false
//     },
//     {
//         name: "Josef",
//         amount: 450500,
//         sex: 'M',
//         is_married: true
//     }
// ];

// class ExcelDownload extends React.Component {
function ExcelDownload({sheetName, excelDataset}) {

  const [displayColumns, setdisplayColumns] = useState([])

  useEffect(() => {
    var displayColumnsObj = []
    if (Object.keys(excelDataset).length > 0) {
      excelDataset.columns.forEach(function (columnItem, index) {
        if (columnItem.isDisplayColumn){
          displayColumnsObj.push(columnItem)
        }
      })
      setdisplayColumns(displayColumnsObj)
    }
    debugger
  }, [excelDataset]);

  return (
      <ExcelFile  element={<Link
          to="#"
          className="btn btn-primary"
          // onClick={processNbrGpsDataMapping}
        >
          <i>
            <FeatherIcon icon="download" className="fea icon-sm" />
          </i>{" "}
          Download Excel
        </Link>}>
          <ExcelSheet data={excelDataset.data} name={sheetName}>
          {
              displayColumns.map((columnItem)=> {
                  return <ExcelColumn label={columnItem.columnName} value={columnItem.columnName}/>
              })
          }
            {/* {Object.keys(excelDataset).length > 0 ? (
              <>
                {displayColumns.map((columnItem, index) => (
                  <ExcelColumn key={index} label={columnItem.columnName} value={columnItem.columnName}/>
                ))}
              </>
            ): (
              <></>
            )} */}
              {/* <ExcelColumn label="Name" value="name"/>
              <ExcelColumn label="Wallet Money" value="amount"/>
              <ExcelColumn label="Gender" value="sex"/> */}
          </ExcelSheet>
      </ExcelFile>
  );
}
export default ExcelDownload;