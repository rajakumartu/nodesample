import  React, { useState, useEffect } from 'react';
import { CSVLink, CSVDownload } from "react-csv";

import { Link } from "react-router-dom";
import FeatherIcon from "feather-icons-react";


// class ExcelDownload extends React.Component {
function CSVDownloadComponent({sheetName, excelDataset}) {

  const [displayColumns, setdisplayColumns] = useState([])


  useEffect(() => {
    var displayColumnsObj = []
    if (Object.keys(excelDataset).length > 0) {
      excelDataset.columns.forEach(function (columnItem, index) {
        if (columnItem.isDisplayColumn){
          displayColumnsObj.push(columnItem)
        }
      })
      setdisplayColumns(displayColumnsObj)
    }
    debugger
  }, [excelDataset]);

  return (
    <>
    {Object.keys(excelDataset).length > 0 ? (
       <CSVLink 
        data={excelDataset.data}
        filename={"download.csv"}
        className="btn btn-primary"
        target="_blank"
        >
          {/* <Link
            to="#"
            className="btn btn-primary"
            // onClick={processNbrGpsDataMapping}
          > */}
            <i>
              <FeatherIcon icon="download" className="fea icon-sm" />
            </i>{" "}
            Download CSV
          {/* </Link> */}
        </CSVLink>
       // or
       // <CSVDownload data={csvData} target="_blank" />;
      ) : (
        <Link
            to="#"
            className="btn btn-primary"
            // onClick={processNbrGpsDataMapping}
          >
            <i>
              <FeatherIcon icon="download" className="fea icon-sm" />
            </i>{" "}
            Download CSV
          </Link>
      )}
  </>);
}
export default CSVDownloadComponent;