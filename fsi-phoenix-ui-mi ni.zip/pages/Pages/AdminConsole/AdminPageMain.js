import React, { Component } from "react";
import {
  Container,
  Row,
  Col,
  Form,
  Input,
  Label,
  Alert,
} from "reactstrap";
import { Link } from "react-router-dom";
import axios from 'axios';
//Import Icons
import FeatherIcon from "feather-icons-react";

//Import components
import PageBreadcrumb from "../../../components/Shared/PageBreadcrumb";

class HelpCenterSupportRequest extends Component {
  constructor(props) {
    super(props);
    this.state = {
      isOpen: false,
    };
    this.handleSubmit.bind(this);
  }

  handleSubmit = (event) => {
    event.preventDefault();
    this.setState({ isOpen: true });
  };

  handleShutdown = () => {
    var hostname = window.location.origin.split('//')[1].split(':')[0]
    axios.get("http://"+hostname+":8080/shutdown").then(
      (response) => {
          var result = response.data;
          console.log(result);
      },
      (error) => {
          console.log(error);
      }
    );
  };

  handleReboot = () => {
    var hostname = window.location.origin.split('//')[1].split(':')[0]
    axios.get("http://"+hostname+":8080/reboot").then(
      (response) => {
          var result = response.data;
          console.log(result);
      },
      (error) => {
          console.log(error);
      }
    );
  };

  componentDidMount() {
    window.addEventListener("scroll", this.scrollNavigation, true);
  }

  // Make sure to remove the DOM listener when the component is unmounted.
  componentWillUnmount() {
    window.removeEventListener("scroll", this.scrollNavigation, true);
  }

  scrollNavigation = () => {
    var doc = document.documentElement;
    var top = (window.pageYOffset || doc.scrollTop) - (doc.clientTop || 0);
    if (top > 80) {
      document.getElementById("topnav").classList.add("nav-sticky");
    } else {
      document.getElementById("topnav").classList.remove("nav-sticky");
    }
  };

  render() {
    return (
      <React.Fragment>
        {/* breadcrumb */}
        <section className="section">
        
          <Container className="mt-100 mt-60">
            <Row>
              <Col lg={6} md={6} xs={12}>
                <div className="d-flex align-items-center features feature-clean shadow rounded p-4">
                  <div className="icons text-danger text-center">
                    <i className="uil uil-envelope-check d-block rounded h3 mb-0"></i>
                  </div>
                  <div className="flex-1 content ms-4">
                    <h5 className="mb-1">
                      <Link to="#" className="text-danger">
                        Shutdown Phoenix Console
                      </Link>
                    </h5>
                    <p className="text-muted mb-0">
                      This action will shutdown the Phoenix Console Device .
                    </p>
                    <div className="mt-2">
                      <Link to="#" className="btn btn-sm btn-soft-danger" onClick={this.handleShutdown}>
                        SHUTDOWN
                      </Link>
                    </div>
                  </div>
                </div>
              </Col>

              <Col lg={6} md={6} xs={12} className="mt-4 mt-sm-0 pt-2 pt-sm-0">
                <div className="d-flex align-items-center features feature-clean shadow rounded p-4">
                  <div className="icons text-danger text-center">
                    <i className="uil uil-webcam d-block rounded h3 mb-0"></i>
                  </div>
                  <div className="flex-1 content ms-4">
                    <h5 className="mb-1">
                      <Link to="#" className="text-danger">
                        Reboot Phoenix Console
                      </Link>
                    </h5>
                    <p className="text-muted mb-0">
                      This action will reboot all service hosted on the Phoenix Console Device .
                    </p>
                    <div className="mt-2">
                      <Link to="#" className="btn btn-sm btn-soft-danger" onClick={this.handleReboot}>
                        REBOOT
                      </Link>
                    </div>
                  </div>
                </div>
              </Col>
            </Row>
          </Container>
        </section>
      </React.Fragment>
    );
  }
}

export default HelpCenterSupportRequest;
