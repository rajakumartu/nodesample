import  React, { useState, useEffect } from 'react';
import { Link } from "react-router-dom";
import {
  Col,
  Container,
  FormGroup,
  Button,
  Modal,
  ModalBody,
  Form,
  ModalHeader,
  Row,
  Table,
} from "reactstrap";
import { Tabs, Tab } from 'react-bootstrap';


import GpsLogDataTable from "./GpsLogDataTable";
import NbrDataTable from "./NbrDataTable"
import NbrGpsMappingData from "./NbrGpsMappingData"

//Import Icons
// import FeatherIcon from "feather-icons-react";
// import CommonSidebar from "./components/CommonSidebar";

// export default class GpsLogDataTable extends Component{
function GpsLogMapper({}) {
    
    const [key, setKey] = useState('gpsNbrData');
    const [gpsData, setGpsData] = useState({})
    const [nbrData, setNbrData] = useState({})
    

    return (
      <React.Fragment>
        
        <section className="section">
          <Container>
            <Row>
              <Col lg={12}>              
                <Tabs
                  id="controlled-tab-example"
                  activeKey={key}
                  onSelect={(k) => setKey(k)}
                  className="mb-3"
                >
                  <Tab eventKey="gpsNbrData" title="NBR GPS Mapping">
                    <NbrGpsMappingData nbrData={nbrData} gpsData={gpsData}  setGpsData={setGpsData} setNbrData={setNbrData} />
                  </Tab>
                  <Tab eventKey="gpsData" title="GPS Data">
                    <GpsLogDataTable gpsData={gpsData} setGpsData={setGpsData} />
                  </Tab>
                  <Tab eventKey="nbrData" title="NBR Data">
                    <NbrDataTable nbrData={nbrData} setNbrData={setNbrData} />
                  </Tab>
                  
                </Tabs>
              </Col>

              {/* <CommonSidebar /> */}
            </Row>
          </Container>
        </section>
      </React.Fragment>
    );
}
export default GpsLogMapper;