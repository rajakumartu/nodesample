import  React, { useState, useEffect } from 'react';
import { Link } from "react-router-dom";
import {
  Col,
  Container,
  FormGroup,
  Button,
  Modal,
  ModalBody,
  Form,
  ModalHeader,
  Row,
  Table,
} from "reactstrap";
import { Tabs, Tab } from 'react-bootstrap';

import NbrDataFileUpload from "./components/NbrDataFileUpload";
import DataTable from "./components/DataTable";
//Import Icons
import FeatherIcon from "feather-icons-react";
import CommonSidebar from "./CommonSidebar";

// export default class GpsLogMapperList extends Component{
function NbrDataTable({nbrData, setNbrData}) {
    
    const [modal, setmodal] = useState(false)
    const [fileContentsRawData, setFileContentsRawData] = useState(null)

    const togglemodal = () => {
      setmodal(!modal)
    };

    useEffect(() => {
      // debugger
      if (fileContentsRawData){
        
        togglemodal()
        let lineContents = fileContentsRawData.split("\n")
        let fileLineList = []
        // for(let line of line_contents) {
        for(var lineNo=3; lineNo<(lineContents.length-3); lineNo++){
            // debugger
            let lineSplit = lineContents[lineNo].split('\t')
            let date = lineSplit[1].split('.')
            let time = lineSplit[2].split(':')
            let dateObj = new Date()
            dateObj.setFullYear('20'+date[2])
            dateObj.setMonth(date[1])
            dateObj.setDate(date[0])
            dateObj.setHours(time[0])
            dateObj.setMinutes(time[1])
            dateObj.setSeconds(time[2])
            fileLineList.push([dateObj, lineSplit[3], lineSplit[4], lineSplit[5], lineSplit[6], lineSplit[12], lineSplit[13]])
            
        }
        setNbrData(fileLineList)   
      }
    }, [fileContentsRawData]);

    return (
      <React.Fragment>
        
        <section className="section">
          <Container>
            <Row>
              <Col lg={12}>              
                {/* <div className="text-center subcribe-form mb-2">
                  
                      <FileUpload returnFileContentsHandler={setFileContentsRawData}/>
                  </div> */}
                <div className="d-flex align-items-center justify-content-between">
                  <h5 className="mb-0">NBR vs Timestamp Data :</h5>
                  {/* <Link
                    to="#"
                    className="btn btn-primary"
                    onClick={togglemodal}
                  >
                    <i>
                      <FeatherIcon icon="plus" className="fea icon-sm" />
                    </i>{" "}
                    Import NBR Data
                  </Link> */}
                  <NbrDataFileUpload  nbrData={nbrData} setNbrData={setNbrData} />
                </div>
                <div className="table-responsive bg-white shadow rounded mt-4">
                {Object.keys(nbrData).length > 0 ? (
                  <DataTable tableData={nbrData} />
                  ) : (
                  <>
                    <FeatherIcon icon="x-circle" className="fea icon-sm"  stroke="red" size="60" />
                    <span> No NBR Data Loaded</span>
                  </>)}
                    {/* <Table className="mb-0 table-center">
                      <thead className="bg-light">
                        <tr>
                          <th
                            scope="col"
                            className="border-bottom text-center"
                            style={{ maxWidth: "150px" }}
                          >
                            Date/Time
                          </th>
                          <th
                            scope="col"
                            className="border-bottom text-center"
                            style={{ width: "100px" }}
                          >
                            int. value
                          </th>
                          <th
                            scope="col"
                            className="border-bottom text-center"
                            style={{ width: "100px" }}
                          >
                            unit int.
                          </th>
                          <th
                            scope="col"
                            className="border-bottom text-center"
                            style={{ width: "100px" }}
                          >
                            ext. value
                          </th>
                          <th
                            scope="col"
                            className="border-bottom text-center"
                            style={{ width: "100px" }}
                          >
                            unit ext.
                          </th>
                          <th
                            scope="col"
                            className="border-bottom text-center"
                            style={{ width: "100px" }}
                          >
                            int. max value
                          </th>
                          <th
                            scope="col"
                            className="border-bottom text-center"
                            style={{ width: "100px" }}
                          >
                            ext. max value
                          </th>
                        </tr>
                      </thead>
                      <tbody>
                      {nbrData.length > 0 ? (
                        <>
                          {nbrData.map((dataItem, index) => ( 
                            <tr key={index}>
                            <td className="text-center small h6">{dataItem[0].toLocaleString()}</td>
                            <td className="text-center small">{dataItem[1]}</td>
                            <td className="text-center small">{dataItem[2]}</td>
                            <td className="text-center small">{dataItem[3]}</td>
                            <td className="text-center small">{dataItem[4]}</td>
                            <td className="text-center small">{dataItem[5]}</td>
                            <td className="text-center small">{dataItem[6]}</td>
                          </tr>
                        ))}
                        </>
                      ) : (
                      
                      <>
                        <FeatherIcon icon="x-circle" className="fea icon-sm"  stroke="red" size="60" />
                        <span> No Nbr Data Loaded</span>
                      </>
                      )}
                      </tbody>
                    </Table> */}
                </div>
              </Col>
              {/* <CommonSidebar /> */}
            </Row>
          </Container>
        </section>
      </React.Fragment>
    );
}
export default NbrDataTable;