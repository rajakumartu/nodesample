import  React, { useState, useEffect } from 'react';
import { Link } from "react-router-dom";
import {
  Col,
  Container,
  FormGroup,
  Button,
  Modal,
  ModalBody,
  Form,
  ModalHeader,
  Row,
  Table,
} from "reactstrap";
import { Tabs, Tab } from 'react-bootstrap';
import GpsDataFileUpload from "./components/GpsDataFileUpload";
import DataTable from "./components/DataTable";
//Import Icons
import FeatherIcon from "feather-icons-react";
import CommonSidebar from "./CommonSidebar";


const moment = require('moment');
// export default class GpsLogMapperList extends Component{
function GpsLogDataTable({gpsData, setGpsData}) {
    
    // const [modal, setmodal] = useState(false)
    // const [fileContentsRawData, setFileContentsRawData] = useState(null)

    // const togglemodal = () => {
    //   setmodal(!modal)
    // };

    // useEffect(() => {
    //   debugger
    //   if (fileContentsRawData){
    //       let lineContents = fileContentsRawData.split(/\r?\n/)
    //       let fileLineList = []
    //       // for(let line of line_contents) {
    //       for(var lineNo=1; lineNo<(lineContents.length-1); lineNo++){
    //           let lineSplit = lineContents[lineNo].split(',')
    //           if (lineSplit){
    //             // console.log(lineSplit)
    //             let date = lineSplit[1].split(' ')[0].split('-')
    //             let time = lineSplit[1].split(' ')[1].split(':')
    //             // let utcDate = new Date(Date.UTC(date[0], date[2], date[1], time[0], time[1], time[2]));
    //             // let mm = moment().utc( lineSplit[1], "YYYY-MM-DD HH:mm:ss" );
    //             let utc_date = new Date()
    //             utc_date.setUTCFullYear(date[0])
    //             utc_date.setUTCMonth(date[1])
    //             utc_date.setUTCDate(date[2])
    //             utc_date.setUTCHours(time[0])
    //             utc_date.setUTCMinutes(time[1])
    //             utc_date.setUTCSeconds(time[2])
  
    //             fileLineList.push([utc_date, lineSplit[2], lineSplit[3]])
    //           }
    //           // debugger
    //       }
    //       setGpsData(fileLineList)
    //       togglemodal()
    //   }
    // }, [fileContentsRawData]);

    return (
      <React.Fragment>
        
        <section className="section">
          <Container>
            <Row>
              <Col lg={12}>              
                {/* <div className="text-center subcribe-form mb-2">
                  
                      <FileUpload returnFileContentsHandler={setFileContentsRawData}/>
                  </div> */}
                <div className="d-flex align-items-center justify-content-between">
                  <h5 className="mb-0">GPS vs Timestamp Data :</h5>
                  {/* <Link
                    to="#"
                    className="btn btn-primary"
                    onClick={togglemodal}
                  >
                    <i>
                      <FeatherIcon icon="plus" className="fea icon-sm" />
                    </i>{" "}
                    Import GPS Data
                  </Link> */}
                  <GpsDataFileUpload  gpsData={gpsData} setGpsData={setGpsData} />
                </div>
                <div className="table-responsive bg-white shadow rounded mt-4">
                {Object.keys(gpsData).length > 0 ? (
                  <DataTable tableData={gpsData}/>
                  ) : (
                  <>
                    <FeatherIcon icon="x-circle" className="fea icon-sm"  stroke="red" size="60" />
                    <span> No GPS Data Loaded</span>
                  </>)}
                </div>
              </Col>

              {/* <CommonSidebar /> */}
            </Row>
          </Container>
        </section>
      </React.Fragment>
    );
}
export default GpsLogDataTable;