import React, { Component } from "react";
import { Link } from "react-router-dom";
import {
  Container,
  Row,
  Col,
  Progress,
  Card,
  CardBody,
  Modal,
  ModalBody,
  Form,
  FormGroup,
  Label,
  Input,
  ModalHeader,
  Dropdown,
  DropdownToggle,
  DropdownMenu,
  DropdownItem,
} from "reactstrap";

//Import Icons
import FeatherIcon from "feather-icons-react";
import GpsLogMapper from "./GpsLogMapper"
//Import Images
import imgbg from "../../../assets/images/account/bg.png";
import profile from "../../../assets/images/client/05.jpg";
import client1 from "../../../assets/images/client/01.jpg";
import client2 from "../../../assets/images/client/02.jpg";
import client3 from "../../../assets/images/client/03.jpg";
import client4 from "../../../assets/images/client/04.jpg";
import client5 from "../../../assets/images/client/05.jpg";
import client6 from "../../../assets/images/client/06.jpg";
import client7 from "../../../assets/images/client/07.jpg";
import client8 from "../../../assets/images/client/08.jpg";

class GpsLogMapperMain extends Component {
  constructor(props) {
    super(props);

    this.state = {
      
      modal: false,
      dropdownOpen: false,
      selectedContacts: [],
    };
    this.togglemodal.bind(this);
    this.toggleDropdown.bind(this);
    this.onChangeCheckbox.bind(this);
  }
  togglemodal = () => {
    this.setState((prevState) => ({
      modal: !prevState.modal,
    }));
  };
  toggleDropdown = () => {
    this.setState({
      dropdownOpen: !this.state.dropdownOpen,
    });
  };

  componentDidMount() {
    document.body.classList = "";
    document.getElementById("top-menu").classList.add("nav-light");
    document.getElementById("buyButton").className = "btn btn-light";
    window.addEventListener("scroll", this.scrollNavigation, true);
  }
  // Make sure to remove the DOM listener when the component is unmounted.
  componentWillUnmount() {
    window.removeEventListener("scroll", this.scrollNavigation, true);
  }

  scrollNavigation = () => {
    var doc = document.documentElement;
    var top = (window.pageYOffset || doc.scrollTop) - (doc.clientTop || 0);
    if (top > 80) {
      document.getElementById("topnav").classList.add("nav-sticky");
      document.getElementById("buyButton").className = "btn btn-primary";
    } else {
      document.getElementById("topnav").classList.remove("nav-sticky");
      document.getElementById("buyButton").className = "btn btn-light";
    }
  };

  onChangeCheckbox = (selected, contact) => {
    let modifiedselectedContacts = [...this.state.selectedContacts];
    if (selected) {
      modifiedselectedContacts.push(contact);
      this.setState({
        selectedContacts: modifiedselectedContacts,
      });
    } else {
      let otherContacts = modifiedselectedContacts.filter(
        (r) => r.id !== contact.id
      );
      this.setState({
        selectedContacts: otherContacts,
      });
    }
  };

  onSelectAll = (checked) => {
    if (checked) {
      this.setState({
        selectedContacts: this.state.members,
      });
    } else {
      this.setState({
        selectedContacts: [],
      });
    }
  };

  render() {
    return (
      <React.Fragment>
        <section
          className="bg-profile d-table w-100 bg-primary"
          style={{ background: `url(${imgbg}) center center` }}
        >
          <Container>
          <Row className="align-items-center">
            <Col lg={7} md={6} xs={12}>
                <div className="title-heading">
                    <h6 className="text-white-50">Data Platform Tools</h6>
                    <h1 className="fw-bold text-white title-dark mt-2 mb-3">NBR GPS Mapper</h1>
                    {/* <p className="para-desc text-white-50">NBR GPS Mapper is a tool that will </p> */}
                </div>
              </Col>
            </Row>
            <Row>
              <Col lg="12">
                <Card
                  className="public-profile-nbr border-0 rounded shadow"
                  style={{ zIndex: "1" , top: "50px"}}
                >
                  <GpsLogMapper />
                </Card>
              </Col>
            </Row>
          </Container>
        </section>
      </React.Fragment>
    );
  }
}

export default GpsLogMapperMain;
