import  React, { useState, useEffect } from 'react';
import { Link } from "react-router-dom";
import {
  Col,
  Container,
  FormGroup,
  Button,
  Modal,
  ModalBody,
  Form,
  ModalHeader,
  Row,
  Table,
} from "reactstrap";
import { Tabs, Tab } from 'react-bootstrap';
import FileUpload from "./FileUpload";
//Import Icons
import FeatherIcon from "feather-icons-react";
// import CommonSidebar from "./CommonSidebar";


const moment = require('moment');
// export default class GpsLogMapperList extends Component{
function DataTable({tableData}) {
  const [displayColumns, setdisplayColumns] = useState([])

  useEffect(() => {
    var displayColumnsObj = []
    tableData.columns.forEach(function (columnItem, index) {
      if (columnItem.isDisplayColumn){
        displayColumnsObj.push(columnItem)
      }
    })
    setdisplayColumns(displayColumnsObj)
  }, [tableData]);


    return (
      <>
        <Table className="mb-0 table-center">
          
          {Object.keys(displayColumns).length > 0 ? (
            
            <thead className="bg-light">
              <tr key={"headercol"} >
                {displayColumns.map((columnItem, index) => (
                  <th
                    key={"headercol"+index}
                    scope="col"
                    className="border-bottom text-center"
                    style={{ maxWidth: columnItem.width }}
                  >
                    {columnItem.columnName}
                  </th>
                ))}
              </tr>
            </thead>
          ):(<></>)}
            {/* <tr>
              <th
                scope="col"
                className="border-bottom text-center"
                style={{ maxWidth: "150px" }}
              >
                Date/Time
              </th>
              <th
                scope="col"
                className="border-bottom text-center"
                style={{ width: "100px" }}
              >
                Lattitude
              </th>
              <th
                scope="col"
                className="border-bottom text-center"
                style={{ width: "100px" }}
              >
                Longitude
              </th>
            </tr> */}
          <tbody>
            <>
              {tableData.data.map((dataItem, rowindex) => ( 
                <tr key={rowindex}>
                  {displayColumns.map((columnItem, colindex) => (
                    <td key={rowindex+" "+colindex} className={columnItem.dataClassName}>{dataItem[columnItem.columnName]}</td>
                    // <>
                    // {columnItem.isDisplayColumn ? (
                      
                    // ):(<></>)}
                    // </>
                  ))}
              </tr>
            ))}
            </>
          
          </tbody>
        </Table>
      </>
    );
}
export default DataTable;