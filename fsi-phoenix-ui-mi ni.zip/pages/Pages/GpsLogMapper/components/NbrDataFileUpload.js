import  React, { useState, useEffect } from 'react';
import { Link } from "react-router-dom";
import {
  Col,
  Container,
  FormGroup,
  Button,
  Modal,
  ModalBody,
  Form,
  ModalHeader,
  Row,
  Table,
} from "reactstrap";
import { Tabs, Tab } from 'react-bootstrap';
import FileUpload from "./FileUpload";
//Import Icons
import FeatherIcon from "feather-icons-react";
// import CommonSidebar from "../CommonSidebar";


const moment = require('moment');
// export default class GpsLogMapperList extends Component{
function NbrLogDataTable({nbrData, setNbrData}) {

  const inputFileFormatRegex = {
    "format": /^([a-zA-Z0-9\s_\\.\-:])+(.his)$/,
    "failureErrorMessage": "Please upload valid '.his' file Format"
  }
  
  const [modal, setmodal] = useState(false)
  const [fileContentsRawData, setFileContentsRawData] = useState(null)

  const togglemodal = () => {
    setmodal(!modal)
  };

  useEffect(() => {
    // debugger
    if (fileContentsRawData){
      
      togglemodal()
      let lineContents = fileContentsRawData.split("\n")
      // let fileLineList = []
      
      let fileLineData = []
      let columnNames = [
        {
          "columnName": "Raw NBR Date/Time",
          "width": "100px",
          "dataClassName": "text-center small h6",
          "isDisplayColumn": false
        },{
          "columnName": "NBR Date/Time",
          "width": "100px",
          "dataClassName": "text-center small h6",
          "isDisplayColumn": true
        },{
          "columnName": "int. value",
          "width": "100px",
          "dataClassName": "text-center small",
          "isDisplayColumn": true
        },{
          "columnName": "unit int.",
          "width": "100px",
          "dataClassName": "text-center small",
          "isDisplayColumn": true
        },{
          "columnName": "ext. value",
          "width": "100px",
          "dataClassName": "text-center small",
          "isDisplayColumn": true
        },{
          "columnName": "unit ext.",
          "width": "100px",
          "dataClassName": "text-center small",
          "isDisplayColumn": true
        },{
          "columnName": "int. max value",
          "width": "100px",
          "dataClassName": "text-center small",
          "isDisplayColumn": true
        },{
          "columnName": "ext. max value",
          "width": "100px",
          "dataClassName": "text-center small",
          "isDisplayColumn": true
        }
      ]

      // for(let line of line_contents) {
      for(var lineNo=3; lineNo<(lineContents.length-3); lineNo++){
          // debugger
          let lineSplit = lineContents[lineNo].split('\t')
          let date = lineSplit[1].split('.')
          let time = lineSplit[2].split(':')
          let dateObj = new Date()
          dateObj.setFullYear('20'+date[2])
          dateObj.setMonth(date[1])
          dateObj.setDate(date[0])
          dateObj.setHours(time[0])
          dateObj.setMinutes(time[1])
          dateObj.setSeconds(time[2])
          // fileLineList.push([dateObj, lineSplit[3], lineSplit[4], lineSplit[5], lineSplit[6], lineSplit[12], lineSplit[13]])
          let itemData = {}
          itemData[columnNames[0].columnName] = dateObj
          itemData[columnNames[1].columnName] = dateObj.toLocaleString()
          itemData[columnNames[2].columnName] = '' + Number(parseFloat(lineSplit[3])).toFixed(3)
          itemData[columnNames[3].columnName] = '' + lineSplit[4]
          itemData[columnNames[4].columnName] = Number(parseFloat(lineSplit[5])).toFixed(3)
          // itemData[columnNames[4].columnName] =  (Math.round((parseFloat(lineSplit[5]) + Number.EPSILON) * 100) / 100).toFixed(3)
          itemData[columnNames[5].columnName] = lineSplit[6]
          itemData[columnNames[6].columnName] = '' + Number(parseFloat(lineSplit[12])).toFixed(3)
          itemData[columnNames[7].columnName] = '' + Number(parseFloat(lineSplit[13])).toFixed(3)
          
          fileLineData.push(itemData)
      }
      setNbrData({
        "data": fileLineData,
        "columns": columnNames
      })
    }
  }, [fileContentsRawData]);

  return (
    <>
      <Link
        to="#"
        className="btn btn-primary"
        onClick={togglemodal}
      >
        <i>
          <FeatherIcon icon="plus" className="fea icon-sm" />
        </i>{" "}
        Import NBR Data
      </Link>
      <Modal
        tabIndex="-1"
        centered
        isOpen={modal}
        toggle={togglemodal}
        contentClassName="rounded shadow border-0"
      >
        <ModalHeader toggle={togglemodal}>
          NBR File Upload
        </ModalHeader>
        <ModalBody className="p-4">
          <FileUpload returnFileContentsHandler={setFileContentsRawData} inputFileFormatRegex={inputFileFormatRegex} />
        </ModalBody>
        {/* <div className="border-top p-4">
          <button type="button" className="btn btn-primary">
            Send Now
          </button>
        </div> */}
      </Modal>
    </>
  );
}
export default NbrLogDataTable;