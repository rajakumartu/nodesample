// React Basic and Bootstrap
// import React, { Component } from 'react';
import  React, { useState, useEffect } from 'react';
// import XLSX from 'xlsx';
import { Container, Row, Col,Form, FormGroup, Label, Input,
    Modal,
    ModalBody,
    ModalHeader
} from 'reactstrap';
import alertTriangleSVG from "../../../../assets/images/illustrator/alert-triangle.svg";

// import { MDBFileInput } from "mdbreact";
var lineReader = require('line-reader');

// import API, { graphqlOperation } from '@aws-amplify/api';

// import { listVaccinationCenters } from '../../graphql/queries';
// import { onCreateWish } from '../../graphql/subscriptions';
// import {createVaccinationCenter } from '../../graphql/mutations';

// class WishWall extends Component {
function FileUpload({returnFileContentsHandler, inputFileFormatRegex}) {
    
    const [modal, setmodal] = useState(false)

    const togglemodal = () => {
        setmodal(!modal)
      };
    // const [rawFileContents, setRawFileContents] = useState(null)
    // const [fileLineContentsList, setFileLineContentsList] = useState(null)
    // useEffect(() => {
    //     debugger
    //     if (rawFileContents){
    //         debugger
    //         returnFileContentsHandler(rawFileContents)
    //     }
    //   }, [rawFileContents]);

    const handleFileUpload = async event => {
        event.preventDefault()
        // debugger
        console.log('handleFileUpload')
        const fileUpload = (document.getElementById('fileupload'));
        // const regex = /^([a-zA-Z0-9\s_\\.\-:])+(.txt|.csv|.his)$/;
        if (inputFileFormatRegex.format.test(fileUpload.value.toLowerCase())) {
            let fileName = fileUpload.files[0].name;
            if (typeof (FileReader) !== 'undefined') {
                const reader = new FileReader();
                if (reader.readAsBinaryString) {
                    reader.onload = (e) => {
                        // processExcel(reader.result);
                        // debugger
                        // console.log(reader.result)
                        // setRawFileContents(reader.result)
                        returnFileContentsHandler(reader.result)
                    };
                    reader.readAsBinaryString(fileUpload.files[0]);
                }
            } else {
                console.log("This browser does not support HTML5.");
            }
        } else {
            togglemodal()
            console.log("Please upload a valid Excel file.");
        }
      }
    

    return (
        <>
            <Form onSubmit={handleFileUpload} className="rounded shadow p-4">
                <Row>                             
                    <Col md="12">
                        <FormGroup className="position-relative">
                            <Label>Upload File :</Label>
                            <Input type="file" className="form-control-file" id="fileupload"/>
                            {/* <MDBFileInput /> */}
                        </FormGroup>                                                                               
                    </Col>
                </Row>
                <Row>
                    <Col sm="12">
                        <input type="submit" id="submit" name="send" className="submitBnt btn btn-primary" value="Apply Now"/>
                    </Col>
                    <Modal
                        isOpen={modal}
                        role="dialog"
                        centered={true}
                        id="trialform"
                        >
                        <ModalHeader toggle={togglemodal}>
                            File Upload Error
                        </ModalHeader>
                        <ModalBody>
                            <div className="feature-form">
                            <img src={alertTriangleSVG} alt="" /> {inputFileFormatRegex.failureErrorMessage}
                                {/* <div className="content mt-4 pt-2">
                                    
                                </div> */}
                            </div>
                        </ModalBody>
                    </Modal>
                </Row>
            </Form>
        </>
    );
}
export default FileUpload;

