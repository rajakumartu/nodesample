import  React, { useState, useEffect } from 'react';
import { Link } from "react-router-dom";
import {
  Col,
  Container,
  FormGroup,
  Button,
  Modal,
  ModalBody,
  Form,
  ModalHeader,
  Row,
  Table,
} from "reactstrap";
import { Tabs, Tab } from 'react-bootstrap';
import FileUpload from "./FileUpload";
//Import Icons
import FeatherIcon from "feather-icons-react";
// import CommonSidebar from "./CommonSidebar";


const moment = require('moment');
// export default class GpsLogMapperList extends Component{
function GpsLogDataTable({gpsData, setGpsData}) {
    
    const inputFileFormatRegex = {
      "format": /^([a-zA-Z0-9\s_\\.\-:])+(.txt|.csv)$/,
      "failureErrorMessage": "Please upload valid '.cvs' or '.txt' file Format"
    }
    const [modal, setmodal] = useState(false)
    const [fileContentsRawData, setFileContentsRawData] = useState(null)

    const togglemodal = () => {
      setmodal(!modal)
    };

    useEffect(() => {
      // debugger
      if (fileContentsRawData){
          let lineContents = fileContentsRawData.split(/\r?\n/)
          // let fileLineList = []
          let fileLineData = []
          let columnNames = [
            {
              "columnName": "Raw GPS Date/Time",
              "width": "100px",
              "dataClassName": "text-center small h6",
              "isDisplayColumn": false
            },{
              "columnName": "GPS Date/Time",
              "width": "100px",
              "dataClassName": "text-center small h6",
              "isDisplayColumn": true
            },{
              "columnName": "Latitude",
              "width": "100px",
              "dataClassName": "text-center small",
              "isDisplayColumn": true
            },{
              "columnName": "Longitude",
              "width": "100px",
              "dataClassName": "text-center small",
              "isDisplayColumn": true
            }]
          // for(let line of line_contents) {
          for(var lineNo=1; lineNo<(lineContents.length-1); lineNo++){
              let lineSplit = lineContents[lineNo].split(',')
              if (lineSplit){
                // console.log(lineSplit)
                let date = lineSplit[1].split(' ')[0].split('-')
                let time = lineSplit[1].split(' ')[1].split(':')
                // let utcDate = new Date(Date.UTC(date[0], date[2], date[1], time[0], time[1], time[2]));
                // let mm = moment().utc( lineSplit[1], "YYYY-MM-DD HH:mm:ss" );
                let utc_date = new Date()
                utc_date.setUTCFullYear(date[0])
                utc_date.setUTCMonth(date[1])
                utc_date.setUTCDate(date[2])
                utc_date.setUTCHours(time[0])
                utc_date.setUTCMinutes(time[1])
                utc_date.setUTCSeconds(time[2])
  
                // fileLineList.push([utc_date, lineSplit[2], lineSplit[3]])
                let itemData = {}
                itemData[columnNames[0].columnName] = utc_date
                itemData[columnNames[1].columnName] = utc_date.toLocaleString()
                itemData[columnNames[2].columnName] = lineSplit[2]
                itemData[columnNames[3].columnName] = lineSplit[3]
                
                fileLineData.push(itemData)
              }
              // debugger
          }
          setGpsData({
            "data": fileLineData,
            "columns": columnNames
          })
          togglemodal()
      }
    }, [fileContentsRawData]);

    return (
      <>
        <Link
          to="#"
          className="btn btn-primary"
          onClick={togglemodal}
        >
          <i>
            <FeatherIcon icon="plus" className="fea icon-sm" />
          </i>{" "}
          Import GPS Data
        </Link>
        <Modal
          tabIndex="-1"
          centered
          isOpen={modal}
          toggle={togglemodal}
          contentClassName="rounded shadow border-0"
        >
          <ModalHeader toggle={togglemodal}>
            GPS File Upload
          </ModalHeader>
          <ModalBody className="p-4">
            <FileUpload returnFileContentsHandler={setFileContentsRawData} inputFileFormatRegex={inputFileFormatRegex}/>
          </ModalBody>
          {/* <div className="border-top p-4">
            <button type="button" className="btn btn-primary">
              Send Now
            </button>
          </div> */}
        </Modal>
      </>
    );
}
export default GpsLogDataTable;