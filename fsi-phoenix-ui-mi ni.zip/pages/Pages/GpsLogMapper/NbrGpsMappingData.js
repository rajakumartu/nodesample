import  React, { useState, useEffect } from 'react';
import { Link } from "react-router-dom";
import {
  Col,
  Container,
  FormGroup,
  Button,
  Modal,
  ModalBody,
  Form,
  ModalHeader,
  Row,
  Table,
} from "reactstrap";
import { Tabs, Tab } from 'react-bootstrap';
import DataTable from "./components/DataTable";
// import FileUpload from "./components/FileUpload";
//Import Icons
import FeatherIcon from "feather-icons-react";
import CommonSidebar from "./CommonSidebar";
// import ExcelDownload from "../../../components/Shared/ExcelDownload";
import CSVDownloadComponent from "../../../components/Shared/CSVDownload";


import NbrDataFileUpload from "./components/NbrDataFileUpload";
import GpsDataFileUpload from "./components/GpsDataFileUpload";

// export default class GpsLogMapperList extends Component{
function NbrGpsMappingData({nbrData, gpsData, setGpsData, setNbrData}) {
    
    const [nbrGpsData, setNbrGpsData] = useState({})

    const processNbrGpsDataMapping = () => {
      // debugger
      let nbrGpsMappingDataList = []
      let gpsDateObjectMap = {}
      let gpsDateKeys = [] 

      let columnNames = [
        {
          "columnName": "NBR Date/Time",
          "width": "100px",
          "dataClassName": "text-center small h6",
          "isDisplayColumn": true
        },{
          "columnName": "GPS Date/Time",
          "width": "100px",
          "dataClassName": "text-center small h6",
          "isDisplayColumn": true
        },{
          "columnName": "Latitude",
          "width": "100px",
          "dataClassName": "text-center small",
          "isDisplayColumn": true
        },{
          "columnName": "Longitude",
          "width": "100px",
          "dataClassName": "text-center small",
          "isDisplayColumn": true
        },{
          "columnName": "int. value",
          "width": "100px",
          "dataClassName": "text-center small",
          "isDisplayColumn": true
        },{
          "columnName": "unit int.",
          "width": "100px",
          "dataClassName": "text-center small",
          "isDisplayColumn": true
        },{
          "columnName": "ext. value",
          "width": "100px",
          "dataClassName": "text-center small",
          "isDisplayColumn": true
        },{
          "columnName": "unit ext.",
          "width": "100px",
          "dataClassName": "text-center small",
          "isDisplayColumn": true
        },{
          "columnName": "int. max value",
          "width": "100px",
          "dataClassName": "text-center small",
          "isDisplayColumn": true
        },{
          "columnName": "ext. max value",
          "width": "100px",
          "dataClassName": "text-center small",
          "isDisplayColumn": true
        }
      ]
      

      gpsData.data.forEach(function (gpsItem, index) {
        gpsDateObjectMap[gpsItem["Raw GPS Date/Time"]] = gpsItem
        gpsDateKeys.push(gpsItem["Raw GPS Date/Time"])
      })
      // debugger
      nbrData.data.forEach(function (nbrItem, index) {
        let nbrDateTimeObj = nbrItem["Raw NBR Date/Time"]
        // debugger
        let filtetedGPSKeys = gpsDateKeys.filter(gpsDateKey => {
          // const time = new Date(entry['dueDate(pin)']).getTime()
          // debugger
          if (gpsDateKey === nbrDateTimeObj){
            return true
          }
          if (gpsDateKey < nbrDateTimeObj){
            var difSeconds = (nbrDateTimeObj - gpsDateKey) / 1000 ;
            if (difSeconds <= 10){
              return true
            }
          }
          return false
        })
        let eligibleGPSKey = filtetedGPSKeys.pop()
        // console.log(nbrDateTimeObj+" "+ eligibleGPSKey)
        let gpsDataItem = {
          "Raw GPS Date/Time": "",
          "GPS Date/Time": "",
          "Latitude": "",
          "Longitude": "",
        }
        if (eligibleGPSKey){
          gpsDataItem = gpsDateObjectMap[eligibleGPSKey]
          
          // nbrGpsMappingDataList.push([nbrDateTimeObj.toLocaleString(), eligibleGPSKey.toLocaleString(), gpsDataItem[1], gpsDataItem[2], nbrItem[1], nbrItem[2], nbrItem[3], nbrItem[4], nbrItem[5], nbrItem[6]])
        // }else{
        //   nbrGpsMappingDataList.push([nbrDateTimeObj.toLocaleString(), "", "", "", nbrItem[1], nbrItem[2], nbrItem[3], nbrItem[4], nbrItem[5], nbrItem[6]])
        }
        let nbrGpsDataItem = Object.assign({}, gpsDataItem, nbrItem);
        let rowItem = {}
        columnNames.forEach(function (columnItem, index) {
          rowItem[columnItem.columnName] = nbrGpsDataItem[columnItem.columnName]
        })
        nbrGpsMappingDataList.push(rowItem)
        // debugger
      })
      setNbrGpsData({
        "data": nbrGpsMappingDataList,
        "columns": columnNames
      })
    };

// Object.entries(playerInningsMap).forEach(([key, instance]) => { return
                        // playerInningsList.map((service, index) => (
                          // Object.keys(playerInningsMap).map((key, index) => (
                        

    useEffect(() => {
      if (Object.keys(gpsData).length > 0 && Object.keys(nbrData).length > 0){
        processNbrGpsDataMapping()
      }

    }, [nbrData, gpsData]);

    return (
      <React.Fragment>
        
        <section className="section">
          <Container>
            <Row>
              <Col lg={12}>              
                {/* <div className="text-center subcribe-form mb-2">
                  
                      <FileUpload returnFileContentsHandler={setFileContentsRawData}/>
                  </div> */}
                <div className="d-flex align-items-center justify-content-between">
                  <h5 className="mb-0">NBR/GPS Mapping Data :</h5>
                  {/* <Link
                    to="#"
                    className="btn btn-primary"
                    onClick={processNbrGpsDataMapping}
                  >
                    <i>
                      <FeatherIcon icon="plus" className="fea icon-sm" />
                    </i>{" "}
                    Process Mapping
                  </Link> */}
                  <NbrDataFileUpload  nbrData={nbrData} setNbrData={setNbrData} />
                  <GpsDataFileUpload  gpsData={gpsData} setGpsData={setGpsData} />
                  {/* <ExcelDownload sheetName={"NBR/GPS Data"} excelDataset={nbrGpsData}/> */}
                  <CSVDownloadComponent sheetName={"NBR/GPS Data"} excelDataset={nbrGpsData}/>


                </div>
                
                <div className="table-responsive bg-white shadow rounded mt-4">
                  {/* <Table className="mb-0 table-center">
                    <thead className="bg-light">
                      <tr>
                        <th
                          scope="col"
                          className="border-bottom text-center"
                          style={{ maxWidth: "150px" }}
                        >
                          NBR Date/Time
                        </th>
                        <th
                          scope="col"
                          className="border-bottom text-center"
                          style={{ width: "100px" }}
                        >
                          GPS Date/Time
                        </th>
                        <th
                          scope="col"
                          className="border-bottom text-center"
                          style={{ width: "100px" }}
                        >
                          Latitude
                        </th>
                        <th
                          scope="col"
                          className="border-bottom text-center"
                          style={{ width: "100px" }}
                        >
                          Longitude
                        </th>
                        <th
                          scope="col"
                          className="border-bottom text-center"
                          style={{ width: "100px" }}
                        >
                          int. value
                        </th>
                        <th
                          scope="col"
                          className="border-bottom text-center"
                          style={{ width: "100px" }}
                        >
                          unit int.
                        </th>
                        <th
                          scope="col"
                          className="border-bottom text-center"
                          style={{ width: "100px" }}
                        >
                          ext. value
                        </th>
                        <th
                          scope="col"
                          className="border-bottom text-center"
                          style={{ width: "100px" }}
                        >
                          unit ext.
                        </th>
                        <th
                          scope="col"
                          className="border-bottom text-center"
                          style={{ width: "100px" }}
                        >
                          int. max value
                        </th>
                        <th
                          scope="col"
                          className="border-bottom text-center"
                          style={{ width: "100px" }}
                        >
                          ext. max value
                        </th>
                      </tr>
                    </thead>
                    <tbody>
                    {nbrGpsData.length > 0 ? (
                      <>
                        {nbrGpsData.map((dataItem, index) => ( 
                          <tr key={index}>
                          <td className="text-center small h6">{dataItem[0]}</td>
                          <td className="text-center small">{dataItem[1]}</td>
                          <td className="text-center small">{dataItem[2]}</td>
                          <td className="text-center small">{dataItem[3]}</td>
                          <td className="text-center small">{dataItem[4]}</td>
                          <td className="text-center small">{dataItem[5]}</td>
                          <td className="text-center small">{dataItem[6]}</td>
                          <td className="text-center small">{dataItem[7]}</td>
                          <td className="text-center small">{dataItem[8]}</td>
                          <td className="text-center small">{dataItem[9]}</td>
                        </tr>
                      ))}
                      </>
                    ) : (<>
                          {nbrData.length == 0 && gpsData.length == 0?(

                            <tr>
                              <td colSpan="8">
                                <FeatherIcon icon="x-circle" className="fea icon-sm"  stroke="red" size="60" />
                                <span>NBR & GPS Data Not Loaded</span>
                              </td>
                            </tr>
                          ):<>
                              {nbrData.length == 0 ? (
                                <>
                                  <tr>
                                    <td colSpan="8">
                                      <FeatherIcon icon="check-circle" className="fea icon-sm"  stroke="green" size="60" />
                                      <span> GPS Data Loaded</span>
                                    </td>
                                  </tr>
                                  <tr>
                                  <td colSpan="8">
                                    <FeatherIcon icon="x-circle" className="fea icon-sm"  stroke="red" size="60" />
                                    <span> NBR Data Not Loaded</span>
                                  </td>
                                </tr>
                              </>) : (
                                <>
                                  <tr>
                                    <td colSpan="8">
                                      <FeatherIcon icon="check-circle" className="fea icon-sm"  stroke="green" size="60" />
                                      <span> NBR Data Loaded</span>
                                    </td>
                                  </tr>
                                  <tr>
                                    <td colSpan="8">
                                      <FeatherIcon icon="x-circle" className="fea icon-sm"  stroke="red" size="60" />
                                      <span> GPS Data Not Loaded</span>
                                    </td>
                                  </tr>
                                </>
                              )}
                          </>}
                  </>)}
                    </tbody>
                  </Table> */}
                  {Object.keys(nbrGpsData).length > 0 ? (
                    <DataTable tableData={nbrGpsData} />
                  ) : (
                    <Table className="mb-0 table-center">
                      <tbody>
                      {Object.keys(nbrData).length == 0 && Object.keys(gpsData).length == 0?(
                        
                          <tr>
                            <td colSpan="8">
                              <FeatherIcon icon="x-circle" className="fea icon-sm"  stroke="red" size="60" />
                              <span>NBR & GPS Data Not Loaded</span>
                            </td>
                          </tr>
                      ):<>
                          {Object.keys(nbrData).length == 0 ? (
                            <>
                              <tr>
                                <td colSpan="8">
                                  <FeatherIcon icon="check-circle" className="fea icon-sm"  stroke="green" size="60" />
                                  <span> GPS Data Loaded</span>
                                </td>
                              </tr>
                              <tr>
                              <td colSpan="8">
                                <FeatherIcon icon="x-circle" className="fea icon-sm"  stroke="red" size="60" />
                                <span> NBR Data Not Loaded</span>
                              </td>
                            </tr>
                          </>) : (
                            <>
                              <tr>
                                <td colSpan="8">
                                  <FeatherIcon icon="check-circle" className="fea icon-sm"  stroke="green" size="60" />
                                  <span> NBR Data Loaded</span>
                                </td>
                              </tr>
                              <tr>
                                <td colSpan="8">
                                  <FeatherIcon icon="x-circle" className="fea icon-sm"  stroke="red" size="60" />
                                  <span> GPS Data Not Loaded</span>
                                </td>
                              </tr>
                            </>
                          )}
                      </>}
                      </tbody>
                      </Table>
                  )}
                </div>
              </Col>

              {/* <CommonSidebar /> */}
            </Row>
          </Container>
        </section>
      </React.Fragment>
    );
}
export default NbrGpsMappingData;