import React, { Component } from "react";
import { Link } from "react-router-dom";
import { Container, Row, Col } from "reactstrap";

//Import Images
import software from "../../assets/images/software/software.png";
import bgimg from "../../assets/images/software/bg.png";

import ScrollspyNav from "../../components/Shared/ScrollspyNav";

class Section extends Component {
  constructor(props) {
    super(props);
    this.state = {
      isOpen: false,
    };
    this.openModal = this.openModal.bind(this);
  }

  openModal() {
    this.setState({ isOpen: true });
  }

  render() {
    return (
      <React.Fragment>
        <section
          className="bg-half-260 bg-primary d-table w-100"
          style={{ background: `url(${bgimg}) center center` }}
        >
          <div className="bg-overlay"></div>
          <Container>
            <Row
              className="align-items-center position-relative mt-5"
              style={{ zIndex: "1" }}
            >
              <Col lg="6" md="12">
                <div className="title-heading mt-4 text-center text-lg-start">
                  <h1 className="heading mb-3 title-dark text-white">
                    FSI Phoenix Data Platform
                  </h1>
                  <p className="para-desc text-white-50">
                    This is a Data Utility Platform build in association with IGCAR addressing all the ETL (Extract, Transform and Load ) needs . This tool provides intutive user experience in viewing and generating reports on complex data . 
                  </p>
                  <div className="mt-4">
                    <ScrollspyNav
                        scrollTargetIds={["features"]}
                        activeNavclassName="active"
                        scrollDuration="800"
                        headerBackground="true"
                      >
                        <a
                          href="#features"
                          className="btn btn-primary rounded mouse-down me-2 mb-2"
                        >
                          View Featues
                        </a>
                        
                      </ScrollspyNav>
                    {/* <Link to="" className="btn btn-light">
                      <i className="uil uil-file-download"></i> View Modules
                    </Link> */}
                  </div>
                </div>
              </Col>


              <Col lg="6" md="12" className="mt-4 pt-2">
                <div className="position-relative">
                  <div className="software_hero">
                    <img src={software} className="img-fluid d-block" alt="" />
                  </div>
                  {/* <div className="play-icon">
                    <Link
                      to="#"
                      className="play-btn lightbox"
                      onClick={this.openModal}
                    >
                      <i className="mdi mdi-play text-primary rounded-circle bg-white shadow"></i>
                    </Link>
                  </div> */}
                </div>
              </Col>
            </Row>
          </Container>
          {/* <ModalVideo
            channel="vimeo"
            isOpen={this.state.isOpen}
            videoId="287684225"
            onClose={() => this.setState({ isOpen: false })}
          /> */}
        </section>
      </React.Fragment>
    );
  }
}

export default Section;
