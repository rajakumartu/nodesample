import React, { Component } from "react";
import { Container, Row, Col, Badge, Alert } from "reactstrap";

//Import Components
import SectionTitle from "../../components/Shared/SectionTitle";
import Feature from "../../components/Shared/Feature";

// import images
import mobile from "../../assets/images/software/mobile-hori.png";

class Features extends Component {
  state = {
    features: [
      {
        id: 1,
        icon: "uil uil-edit-alt h1 text-primary",
        title: "Data Trasformations",
        description:
          "Ability to transform large amount of data from one format to another",
      },
      {
        id: 2,
        icon: "uil uil-vector-square h1 text-primary",
        title: "Data Export",
        description:
          "Export data into different formats (e.g excel, csv ..etc) and make it available for download .",
      },
      {
        id: 3,
        icon: "uil uil-file-search-alt h1 text-primary",
        title: "Data Analysis",
        description:
          "Ability to analyse data based on specic business rules and generate/export/filter data and generate reports based on requirements.",
      },
      {
        id: 4,
        icon: "uil uil-airplay h1 text-primary",
        title: "Intuitive UI",
        description:
          "This utility provides intuitive and user friendly interface , which is powered with various dashbords for easy of viewing complex data.",
      },
      {
        id: 5,
        icon: "uil uil-calendar-alt h1 text-primary",
        title: "Batch Processing",
        description:
          "Ability to schedule batch jobs to source and process data from different data sources and prepare reports",
      },
      {
        id: 6,
        icon: "uil uil-fast-mail h1 text-primary",
        title: "E-Mail",
        description:
          "Ability to send email notification and reports.",
      },
    ],
  };

  componentDidMount() {
    var featureboxes = document.getElementsByName("featurebox");
    for (var i = 0; i < featureboxes.length; i++) {
      featureboxes[i].classList.add("mt-5");
    }
  }
  render() {
    return (
      <React.Fragment>
        <Container>
          {/* Render Section Title */}
          <SectionTitle
            title="Features"
            desc="The Fetaures and Capabilities of FSI Phoenix Data Platform."
          />

          {/* feature box */}
          <Feature featureArray={this.state.features} isCenter={true} />

          <Row className="justify-content-center mt-5 pt-4">
            <Col lg="10" md="12">
              <img src={mobile} className="img-fluid d-block mx-auto" alt="" />
            </Col>
            {/* <Col xs="12" className="text-center pt-2">
              <Alert color="light" className="alert-pills shadow">
                <Badge className="rounded-pill bg-primary me-1">
                  Download
                </Badge>
                <span className="content">
                  {" "}
                  Trusted by the world's best{" "}
                  <i className="uil uil-cloud-download"></i>
                </span>
              </Alert>
            </Col> */}
          </Row>
        </Container>
      </React.Fragment>
    );
  }
}

export default Features;
