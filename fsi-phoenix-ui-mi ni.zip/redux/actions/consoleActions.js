import * as types from "./actionTypes";

export function consoleShutdown() {
  // debugger
  return function(dispatch) {
    axios.get("http://localhost:8080/shutdown").then(
      (response) => {
          var result = response.data;
          console.log(result);
      },
      (error) => {
          console.log(error);
      }
    );
  }
}

export function consoleReboot() {
  // debugger
  return function(dispatch) {
    axios.get("http://localhost:8080/reboot").then(
      (response) => {
          var result = response.data;
          console.log(result);
      },
      (error) => {
          console.log(error);
      }
    );
  }
}