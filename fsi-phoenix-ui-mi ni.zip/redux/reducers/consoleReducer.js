import * as types from "../actions/actionTypes";
import initialState from "./initialState";


export default function consoleReducer(state = initialState.center, action) {
  switch (action.type) {
    default:
      return state;
  }
}
