import { combineReducers } from "redux";
import user from "./userReducer";
import auth from "./authReducer";
import console from "./consoleReducer";

const rootReducer = combineReducers({
  // user,
  auth,
  console
});

export default rootReducer;
