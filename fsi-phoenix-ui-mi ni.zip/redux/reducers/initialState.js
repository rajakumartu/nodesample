export default {
  auth:{
    user: {},
    isAuthUser: false,
    loginFormState: 'signIn'
  },
  // }
  center: {
    dataList: [],
    dataMap: {},
    selectedLocateCenter: {}
  }
  // isAuthUser: false
  
//   {
//     'attributes' : { 
//         'email' : '',
//         'family_name' : '' ,
//         'given_name' : ''
//     }
// },
};
