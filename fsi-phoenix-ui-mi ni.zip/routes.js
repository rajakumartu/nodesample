import React from "react";

// Root Include
const Root = React.lazy(() => import("./pages/Home/indexRoot"));

//Main Index
const Main = React.lazy(() => import("./pages/Home/indexMain"));

//Special
const PageComingSoon = React.lazy(() =>
  import("./pages/Pages/Special/PageComingSoon")
);
const PageComingSoon2 = React.lazy(() =>
  import("./pages/Pages/Special/PageComingSoon2")
);
const PageError = React.lazy(() => import("./pages/Pages/Special/PageError"));
const PageThankYou = React.lazy(() =>
  import("./pages/Pages/Special/PageThankYou")
);
const PageMaintenance = React.lazy(() =>
  import("./pages/Pages/Special/PageMaintenance")
);

//Auth Pages
const PageLogin = React.lazy(() => import("./pages/Pages/AuthPages/PageLogin"));
const PageCoverLogin = React.lazy(() =>
  import("./pages/Pages/AuthPages/PageCoverLogin")
);
const PageLoginThree = React.lazy(() =>
  import("./pages/Pages/AuthPages/PageLoginThree")
);

const PageSignup = React.lazy(() =>
  import("./pages/Pages/AuthPages/PageSignup")
);
const PageCoverSignup = React.lazy(() =>
  import("./pages/Pages/AuthPages/PageCoverSignup")
);
const PageSignupThree = React.lazy(() =>
  import("./pages/Pages/AuthPages/PageSignupThree")
);

const PageCoverRePassword = React.lazy(() =>
  import("./pages/Pages/AuthPages/PageCoverRePassword")
);
const PageRecoveryPassword = React.lazy(() =>
  import("./pages/Pages/AuthPages/PageRecoveryPassword")
);
const PageRePasswordThree = React.lazy(() =>
  import("./pages/Pages/AuthPages/PageRePasswordThree")
);

const GpsLogMapperMain = React.lazy(() => import("./pages/Pages/GpsLogMapper/GpsLogMapperMain"));
const FsiContact = React.lazy(() => import("./pages/Pages/FsiContact/PageContactDetail"));
const AdminConsole = React.lazy(() => import("./pages/Pages/AdminConsole/AdminPageMain"));


const PhoenixHome = React.lazy(() => import("./pages/PhoenixHome/index"));


const routes = [
  //routes without Layout

  //Contct without layout
  // {
  //   path: "/page-contact-detail",
  //   component: PageContactDetail,
  //   isWithoutLayout: true,
  //   isTopbarDark: true
  // },

  // //Email Pages
  // { path: "/email-alert", component: EmailAlert, isWithoutLayout: true },
  // {
  //   path: "/email-password-reset",
  //   component: EmailPasswordReset,
  //   isWithoutLayout: true,
  // },
  // {
  //   path: "/email-confirmation",
  //   component: EmailConfirmation,
  //   isWithoutLayout: true,
  // },
  // { path: "/email-invoice", component: EmailInvoice, isWithoutLayout: true },

  // //Special Pages
  // {
  //   path: "/page-comingsoon",
  //   component: PageComingSoon,
  //   isWithoutLayout: true,
  // },
  // {
  //   path: "/page-comingsoon2",
  //   component: PageComingSoon2,
  //   isWithoutLayout: true,
  // },
  // { path: "/page-error", component: PageError, isWithoutLayout: true },
  // { path: "/page-thankyou", component: PageThankYou, isWithoutLayout: true },
  // {
  //   path: "/page-maintenance",
  //   component: PageMaintenance,
  //   isWithoutLayout: true,
  // },

  // //User Pages
  // { path: "/auth-login", component: PageLogin, isWithoutLayout: true },
  // {
  //   path: "/auth-cover-login",
  //   component: PageCoverLogin,
  //   isWithoutLayout: true,
  // },
  // {
  //   path: "/auth-login-three",
  //   component: PageLoginThree,
  //   isWithoutLayout: true,
  // },

  // { path: "/auth-signup", component: PageSignup, isWithoutLayout: true },
  // {
  //   path: "/auth-cover-signup",
  //   component: PageCoverSignup,
  //   isWithoutLayout: true,
  // },
  // {
  //   path: "/auth-signup-three",
  //   component: PageSignupThree,
  //   isWithoutLayout: true,
  // },

  // {
  //   path: "/auth-re-password",
  //   component: PageRecoveryPassword,
  //   isWithoutLayout: true,
  // },
  // {
  //   path: "/auth-cover-re-password",
  //   component: PageCoverRePassword,
  //   isWithoutLayout: true,
  // },
  // {
  //   path: "/auth-re-password-three",
  //   component: PageRePasswordThree,
  //   isWithoutLayout: true,
  // },

  // // Landings
  // { path: "/index-onepage", component: SaasOnepage, isTopbarDark: true },
  // { path: "/index-customer", component: Customer, isTopbarDark: true },
  // { path: "/index-job", component: Job, isTopbarDark: true },
  // { path: "/index-software", component: Software },
  // { path: "/index-crypto", component: Cryptocurrency },
  // { path: "/index-payments", component: Payments, isTopbarDark: true },
  // { path: "/index-car-riding", component: IndexCarRiding, isTopbarDark: true },
  // { path: "/index-classic-saas", component: IndexclassicSaas, isTopbarDark: true },
  // { path: "/index-classic-app", component: ClassicApp, isTopbarDark: true },
  // { path: "/index-saas", component: Saas, isTopbarDark: true },
  // { path: "/index-apps", component: Apps, isTopbarDark: true },
  // { path: "/index-agency", component: Agency, isTopbarDark: true },
  // { path: "/index-studio", component: Studio, isTopbarDark: true },
  // { path: "/index-business", component: Business, isTopbarDark: true },
  // { path: "/index-corporate", component: CorporateBusiness },
  // { path: "/index-it-solution", component: ITSolution },
  // { path: "/index-marketing", component: Marketing, isTopbarDark: true },
  // { path: "/index-hotel", component: Hotel, isTopbarDark: true },
  // { path: "/index-developer", component: Developer, isTopbarDark: true },
  // { path: "/index-landing-four", component: LandingFour, isTopbarDark: true },
  // { path: "/index-integration", component: Integration },
  // { path: "/index-task-management", component: TaskManagement },
  // { path: "/index-hospital", component: Hospital, isTopbarDark: true },
  // { path: "/index-construction", component: Construction },
  // { path: "/index-email-inbox", component: EmailInbox, isTopbarDark: true },
  // { path: "/index-landing-one", component: LandingOne },
  // { path: "/index-landing-two", component: LandingTwo, isTopbarDark: true },
  // { path: "/index-landing-three", component: LandingThree },
  // { path: "/index-travel", component: Travel },
  // { path: "/index-blog", component: Blog, isTopbarDark: true },
  // { path: "/index-forums", component: Forums, isTopbarDark: true },
  // { path: "/index-real-estate", component: RealEstate },
  // { path: "/index-seo-agency", component: SeoAgency, isTopbarDark: true },
  // { path: "/index-modern-business", component: ModernBusiness },
  // { path: "/index-coworking", component: Coworking },
  // { path: "/index-hosting", component: CloudHosting },
  // { path: "/index-event", component: Event },
  // { path: "/index-course", component: Course },
  // { path: "/index-personal", component: Personal, isTopbarDark: true },
  // { path: "/index-single", component: SingleProduct, isTopbarDark: true },
  // { path: "/index-enterprise", component: Enterprise },
  // { path: "/index-portfolio", component: Portfolio, isTopbarDark: true },
  // { path: "/index-services", component: Services, isTopbarDark: true },
  // { path: "/index-shop", component: Shop, isTopbarDark: true },
  // { path: "/index-insurance", component: Insurance },
  // { path: "/index-ebook", component: Ebook, isTopbarDark: true },
  // { path: "/index-social-marketing", component: SocialMarketing, isTopbarDark: true },
  // { path: "/index-digital-agency", component: DigitalAgency, isTopbarDark: true },
  // { path: "/index-online-learning", component: OnlineLearning, isTopbarDark: true },
  // { path: "/index-finance", component: Finance, isTopbarDark: true },
  // { path: "/index-videocall", component: VideoCall, isTopbarDark: true },
  // { path: "/index-it-solution-two", component: iTSolutionTwo },
  // { path: "/index-freelancer", component: Freelancer, isTopbarDark: true },
  // { path: "/index-blockchain", component: Blockchain },
  // { path: "/index-crypto-two", component: CryptoTwo },

  // { path: "/page-aboutus", component: PageAboutUs, isTopbarDark: true },
  // { path: "/page-aboutus-two", component: PageAboutusTwo },
  // { path: "/page-history", component: PageHistory, isTopbarDark: true },
  // { path: "/page-pricing", component: PagePricing, isTopbarDark: true },
  // { path: "/page-services", component: PageServices, isTopbarDark: true },
  // { path: "/page-team", component: PageTeam, isTopbarDark: true },

  // //Help Center
  // { path: "/helpcenter-overview", component: HelpCenterOverview, isTopbarDark: true },
  // { path: "/helpcenter-faqs", component: HelpCenterFaqs, isTopbarDark: true },
  // { path: "/helpcenter-guides", component: HelpCenterGuides, isTopbarDark: true },
  // { path: "/helpcenter-support-request", component: HelpCenterSupportRequest, isTopbarDark: true },

  // //Shop
  // { path: "/shop-grids", component: ShopProducts, isTopbarDark: true },
  // { path: "/shop-lists", component: ShopProductsLists, isTopbarDark: true },
  // { path: "/shop-product-detail", component: ShopProductDetail, isTopbarDark: true },
  // { path: "/shop-cart", component: ShopCart, isTopbarDark: true },
  // { path: "/shop-checkouts", component: ShopCheckouts, isTopbarDark: true },
  // { path: "/shop-myaccount", component: ShopMyAccount, isTopbarDark: true },

  // //Utility
  // { path: "/page-terms", component: PageTerms, isTopbarDark: true },
  // { path: "/page-privacy", component: PagePrivacy, isTopbarDark: true },

  // //Page Work
  // { path: "/page-work-modern", component: PageWorkModern, isTopbarDark: true },
  // { path: "/page-work-detail", component: PageWorkDetail, isTopbarDark: true },
  // { path: "/page-work-classic", component: PageWorkClassic, isTopbarDark: true },
  // { path: "/page-work-grid", component: PageWorkGrid, isTopbarDark: true },
  // { path: "/page-work-masonry", component: PageWorkMasonry, isTopbarDark: true },

  // //Page Profile
  // { path: "/page-profile", component: PageProfile },
  // { path: "/page-members", component: PageMembers },
  // { path: "/page-works", component: PageWorks },
  // { path: "/page-messages", component: PageMessages },
  // { path: "/page-profile-edit", component: PageProfileEdit },
  // { path: "/page-payments", component: PagePayments },
  // { path: "/page-invoice", component: PageInvoice, isTopbarDark: true },

  // //Page Job
  // { path: "/page-job", component: PageJob, isTopbarDark: true },
  // { path: "/page-job-apply", component: PageJobApply, isTopbarDark: true },
  // { path: "/page-job-detail", component: PageJobDetail, isTopbarDark: true },
  // { path: "/page-jobs-sidebar", component: PageJobsSidebar, isTopbarDark: true },
  // { path: "/page-job-company-list", component: PageCompanyList, isTopbarDark: true },
  // { path: "/page-job-candidate-list", component: PageCandidateList, isTopbarDark: true },
  // { path: "/page-job-company", component: PageJobCompany },
  // { path: "/page-job-candidate", component: PageJobCandidate },

  // //Page Blog
  // { path: "/page-blog-grid", component: PageBlog, isTopbarDark: true },
  // { path: "/page-blog-detail", component: PageBlogDetail, isTopbarDark: true },
  // { path: "/page-blog-detail-two", component: PageBlogDetailTwo },
  // { path: "/page-blog-sidebar", component: PageBlogSidebar, isTopbarDark: true },
  // { path: "/page-blog-list", component: PageBlogList, isTopbarDark: true },
  // { path: "/page-blog-list-sidebar", component: PageBlogListSidebar, isTopbarDark: true },

  // //Page Case Study
  // { path: "/page-all-cases", component: AllCases },
  // { path: "/page-case-detail", component: CaseDetail, isTopbarDark: true },

  // //Page Contact
  // { path: "/page-contact-one", component: PageContactOne, isTopbarDark: true },
  // { path: "/page-contact-three", component: PageContactThree, isTopbarDark: true },
  // { path: "/page-contact-two", component: PageContactTwo, isTopbarDark: true },

  // // forums
  // { path: "/forums", component: Overview, isTopbarDark: true },
  // { path: "/forums-topic", component: ForumTopic, isTopbarDark: true },
  // { path: "/forums-comments", component: ForumsComments, isTopbarDark: true },

  // forums
  // { path: "/forums", component: Overview, isTopbarDark: true },
  { path: "/gps-log-mapper", component: GpsLogMapperMain, isTopbarDark: false },
  { path: "/fsi-contact", component: FsiContact, isTopbarDark: true },
  { path: "/admin-console", component: AdminConsole, isTopbarDark: true },
  // { path: "/forums-comments", component: ForumsComments, isTopbarDark: true },


  // //Docs
  // { path: "/changelog", component: ChangeLog, isTopbarDark: true },
  // { path: "/components", component: Components, isTopbarDark: true },
  // { path: "/documentation", component: Documentation, isTopbarDark: true },
  // { path: "/widget", component: Widget, isTopbarDark: true },

  // //Index Main
  // { path: "/index", component: Main, isTopbarDark: true },
  { path: "/index", component: PhoenixHome, isTopbarDark: false },
  //Index root

  { path: "/", component: PhoenixHome, exact: true },
  // { path: "/", component: PhoenixHome, isWithoutLayout: true, exact: true },
  { component: PageError, isWithoutLayout: true, exact: false },
];

export default routes;
