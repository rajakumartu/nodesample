import React from "react";
import ReactDOM from "react-dom";
import App from "./App";
import * as serviceWorker from "./serviceWorker";
import { BrowserRouter } from "react-router-dom";
import configureStore from "./redux/configureStore";
import { Provider as ReduxProvider } from "react-redux";

const store = configureStore();

const app = (
    <ReduxProvider store={store}>
        <BrowserRouter>
            <App />
            {/* <AppWithAuth /> */}
        </BrowserRouter>
    </ReduxProvider>
);

ReactDOM.render(app, document.getElementById('root'));
serviceWorker.unregister();