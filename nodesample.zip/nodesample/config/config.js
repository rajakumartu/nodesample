'use strict';

const config = {
  version: process.env.VERSION || '1.0',
};

module.exports = config;
