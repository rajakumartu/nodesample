#!/bin/bash
echo "...Start Rest Service Script..."

cd /usr/local/fsi/fsi-phoenix-rest/
export APPLICATION_PORT=8080
export BASE_PATH=/usr/local/fsi/fsi-phoenix-rest/src

sudo apt install python3-pip
pip3 install -r requirements.txt

python3 src/app.py
