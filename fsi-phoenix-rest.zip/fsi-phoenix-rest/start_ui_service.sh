#!/bin/bash
echo "...Start UI Service Script..."

aws ecr get-login-password --region us-east-1 --profile phoenix-client| sudo docker login --username AWS --password-stdin 419850723644.dkr.ecr.us-east-1.amazonaws.com


sudo docker run -d --platform linux/arm/v7 --name fsi-phoenix-ui -p 3000:3000 \
--env APPLICATION_PORT=3000 \
--env SKIP_PREFLIGHT_CHECK=true \
 --rm 419850723644.dkr.ecr.us-east-1.amazonaws.com/fsi-phoenix-ui:1.3
