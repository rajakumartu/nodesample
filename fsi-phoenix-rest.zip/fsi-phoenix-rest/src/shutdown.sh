#!/bin/bash
echo "...ShutDown Script..."
sudo shutdown