#!/bin/bash
echo "...Reboot Script..."
sudo reboot