import os
from flask import Flask, jsonify, request
import logging
from subprocess import run, PIPE

logger = logging.getLogger(__name__)
app = Flask(__name__)


def print_curr_dir_path():
    # command = ['sh', './src/shutdown.sh']
    print('Current Directory')
    command = ['pwd']
    result = run(command, stdout=PIPE, stderr=PIPE, universal_newlines=True)
    print(result.returncode, result.stdout, result.stderr)


@app.route('/health', methods=['GET'])
def health():
    logger.info("Health Status OK")
    return {'Status': 'Sucesss Client'}


@app.route('/shutdown', methods=['GET'])
def shutdown():
    logger.info("Shutdown")
    base_path = os.environ['BASE_PATH']
    # subprocess.call(['sh', './test.sh'])
    print_curr_dir_path()
    # p = Popen(, stdin=PIPE, stdout=PIPE, stderr=PIPE)
    command = ['sh', f'{base_path}/shutdown.sh']
    # command = ['pwd']
    result = run(command, stdout=PIPE, stderr=PIPE, universal_newlines=True)
    print(result.returncode, result.stdout, result.stderr)

    response = jsonify({'response': str(result.stdout)})
    response.headers.add('Access-Control-Allow-Origin', '*')
    return response


@app.route('/reboot', methods=['GET'])
def reboot():
    logger.info("Reboot")
    base_path = os.environ['BASE_PATH']
    # subprocess.call(['sh', './test.sh'])
    print_curr_dir_path()
    # p = Popen(, stdin=PIPE, stdout=PIPE, stderr=PIPE)
    command = ['sh', f'{base_path}/reboot.sh']
    # command = ['pwd']
    result = run(command, stdout=PIPE, stderr=PIPE, universal_newlines=True)
    print(result.returncode, result.stdout, result.stderr)

    response = jsonify({'response': str(result.stdout)})
    response.headers.add('Access-Control-Allow-Origin', '*')
    return response


if __name__ == '__main__':
    logger.info("Staring REST Service .....")
    port = os.environ['APPLICATION_PORT']
    print(f"Port Configured : {port}")
    logger.info(f"Port Configured : {port}")
    app.run(host='0.0.0.0', port=port)