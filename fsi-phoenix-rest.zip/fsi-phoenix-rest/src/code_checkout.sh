#!/bin/bash
echo "...Reload Sources..."
PROJECT_DIRECTORY="fsi-phoenix-rest"
cd $PROJECT_DIRECTORY
git checkout -b develop
git pull --rebase origin develop

PROJECT_DIRECTORY="fsi-phoenix-ui"
cd $PROJECT_DIRECTORY
git checkout -b develop
git pull --rebase origin develop
